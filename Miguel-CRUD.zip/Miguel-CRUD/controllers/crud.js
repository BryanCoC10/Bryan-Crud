//Invocamos a la conexion de la DB
const conexion = require('../database/db');

//GUARDAR un REGISTRO
exports.save = (req, res) => {
    const nombre = req.body.nombre;
    const apellido = req.body.apellido;
    const correo = req.body.correo;
    const contraseña = req.body.contraseña;
    conexion.query('INSERT INTO users SET ?', { nombre: nombre, apellido: apellido, correo: correo, contraseña: contraseña }, (error, results) => {
        if (error) {
            console.log(error);
        } else {
            //console.log(results);
            res.redirect('/');
        }
    });
};
//ACTUALIZAR un REGISTRO
exports.update = (req, res) => {
    const id = req.body.id;
    const nombre = req.body.nombre;
    const apellido = req.body.apellido;
    const correo = req.body.correo;
    const contraseña = req.body.contraseña;
    conexion.query('UPDATE users SET ? WHERE id = ?', [{ nombre: nombre, apellido: apellido, correo: correo, contraseña: contraseña }, id], (error, results) => {
        if (error) {
            console.log(error);
        } else {
            res.redirect('/');
        }
    });
};