const express = require('express')
const app = express()
const port = 5000

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: false }))
app.use(express.json())

app.use('/', require('./router'));

app.get('/', (req, res) => res.send('FUNCIONA!'))
app.listen(port, () => console.log(`SERVER funcionando en http://localhost:${port}`))
